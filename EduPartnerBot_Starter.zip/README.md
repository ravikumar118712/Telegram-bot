# EduPartner Bot (Starter)

Replace BOT_TOKEN in config.py, then:

pip install -r requirements.txt
python bot.py
