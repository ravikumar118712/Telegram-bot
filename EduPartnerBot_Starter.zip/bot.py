from telegram import Update
from telegram.ext import Application,CommandHandler,ContextTypes
from config import BOT_TOKEN

async def start(update:Update,context:ContextTypes.DEFAULT_TYPE):
    await update.message.reply_text(
        "Welcome to EduPartner!\n\n"
        "Version 1 Starter Bot is running.\n"
        "Next features: Partner ID, Referral, Registration."
    )

app=Application.builder().token(BOT_TOKEN).build()
app.add_handler(CommandHandler("start",start))
app.run_polling()
